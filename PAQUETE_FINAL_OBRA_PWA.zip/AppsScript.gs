
function costoActividadMateriales(actividad){
  const sh = SpreadsheetApp.getActive().getSheetByName("Actividad_Material").getDataRange().getValues();
  let t=0;
  for(let i=1;i<sh.length;i++){
    if(sh[i][1]==actividad) t+=Number(sh[i][3])*Number(sh[i][4]);
  }
  return t;
}

function costoManoObraActividad(actividad){
  const sh = SpreadsheetApp.getActive().getSheetByName("Actividad_ManoObra").getDataRange().getValues();
  let t=0;
  for(let i=1;i<sh.length;i++){
    if(sh[i][1]==actividad) t+=Number(sh[i][3])*Number(sh[i][4]);
  }
  return t;
}

function costoActividad(actividad){
  return costoActividadMateriales(actividad)+costoManoObraActividad(actividad);
}

function costoServicio(servicio){
  const sh = SpreadsheetApp.getActive().getSheetByName("Servicio_Actividad").getDataRange().getValues();
  let t=0;
  for(let i=1;i<sh.length;i++){
    if(sh[i][1]==servicio) t+=costoActividad(sh[i][2]);
  }
  return t;
}

function costoProyecto(proyecto){
  const sh = SpreadsheetApp.getActive().getSheetByName("Cliente_Servicio").getDataRange().getValues();
  let t=0;
  for(let i=1;i<sh.length;i++){
    if(sh[i][2]==proyecto) t+=costoServicio(sh[i][3]);
  }
  return t;
}

function doGet(e){
  let r={};
  if(e.parameter.actividad) r={tipo:"actividad",total:costoActividad(e.parameter.actividad)};
  if(e.parameter.servicio) r={tipo:"servicio",total:costoServicio(e.parameter.servicio)};
  if(e.parameter.proyecto) r={tipo:"proyecto",total:costoProyecto(e.parameter.proyecto)};
  return ContentService.createTextOutput(JSON.stringify(r)).setMimeType(ContentService.MimeType.JSON);
}
